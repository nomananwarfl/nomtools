import { Header } from "@/components/Header";
import { HeroSection } from "@/components/HeroSection";
import { FavoritesSection } from "@/components/FavoritesSection";
import { ToolsSection } from "@/components/ToolsSection";
import { Footer } from "@/components/Footer";

const Index = () => {
  return (
    <div className="min-h-screen bg-background">
      <Header />
      <HeroSection />
      <FavoritesSection />
      <ToolsSection />
      <Footer />
    </div>
  );
};

export default Index;
