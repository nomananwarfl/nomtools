import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Heart } from "lucide-react";
import { Link } from "react-router-dom";

export const FavoritesSection = () => {
  return (
    <section className="py-16 bg-gradient-secondary">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <div className="flex items-center justify-center mb-4">
            <Heart className="w-8 h-8 text-accent mr-3" />
            <h2 className="text-3xl font-bold text-foreground">Favorite Tools</h2>
          </div>
          <p className="text-muted-foreground text-lg">
            Quickly access your favorite tools.
          </p>
        </div>

        <Card className="max-w-4xl mx-auto shadow-blue">
          <CardContent className="p-12 text-center">
            <div className="mb-6">
            </div>
            <div className="mb-4"></div>
            <div className="mb-4"></div>
            <div className="mb-4"></div>
            <div className="mb-4"></div>
            <Button asChild className="bg-gradient-primary hover:opacity-90 transition-opacity shadow-blue px-8 py-3">
              <Link to="/contact">Contact</Link>
            </Button>
          </CardContent>
        </Card>
      </div>
    </section>
  );
};