import { Card, CardContent } from "@/components/ui/card";
import { LucideIcon } from "lucide-react";

interface ToolCardProps {
  title: string;
  icon: LucideIcon;
  description?: string;
}

export const ToolCard = ({ title, icon: Icon, description }: ToolCardProps) => {
  return (
    <Card className="group cursor-pointer transition-all duration-300 hover:shadow-blue-lg hover:-translate-y-1 bg-card border-border">
      <CardContent className="p-6 text-center">
        <div className="mb-4 flex justify-center">
          <div className="w-16 h-16 rounded-xl bg-gradient-primary flex items-center justify-center group-hover:scale-110 transition-transform duration-300">
            <Icon className="w-8 h-8 text-white" />
          </div>
        </div>
        <h3 className="font-semibold text-foreground group-hover:text-primary transition-colors">
          {title}
        </h3>
        {description && (
          <p className="text-sm text-muted-foreground mt-2">
            {description}
          </p>
        )}
      </CardContent>
    </Card>
  );
};