import { Button } from "@/components/ui/button";
import { Heart } from "lucide-react";

export const Footer = () => {
  return (
    <footer className="bg-primary text-primary-foreground py-16">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
          {/* Logo & Description */}
          <div className="col-span-1 md:col-span-2">
            <div className="flex items-center space-x-2 mb-4">
              <div className="w-8 h-8 bg-white rounded-lg flex items-center justify-center">
                <span className="text-primary font-bold text-sm">N</span>
              </div>
              <h3 className="text-2xl font-bold">Nom Tools</h3>
            </div>
            <p className="text-primary-foreground/80 mb-4 max-w-md">
              Your ultimate collection of online tools for productivity, analysis, and conversion. 
              Making complex tasks simple, one tool at a time.
            </p>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="font-semibold mb-4">Quick Links</h4>
            <ul className="space-y-2">
              <li><a href="#" className="text-primary-foreground/80 hover:text-white transition-colors">Home</a></li>
              <li><a href="#" className="text-primary-foreground/80 hover:text-white transition-colors">All Tools</a></li>
              <li><a href="#" className="text-primary-foreground/80 hover:text-white transition-colors">Categories</a></li>
              <li><a href="#" className="text-primary-foreground/80 hover:text-white transition-colors">Favorites</a></li>
            </ul>
          </div>

          {/* Support */}
          <div>
            <h4 className="font-semibold mb-4">Support</h4>
            <ul className="space-y-2">
              <li><a href="#" className="text-primary-foreground/80 hover:text-white transition-colors">About Us</a></li>
              <li><a href="#" className="text-primary-foreground/80 hover:text-white transition-colors">Contact Us</a></li>
              <li><a href="#" className="text-primary-foreground/80 hover:text-white transition-colors">Privacy Policy</a></li>
              <li><a href="#" className="text-primary-foreground/80 hover:text-white transition-colors">Terms of Service</a></li>
            </ul>
          </div>
        </div>

        <div className="border-t border-primary-foreground/20 pt-8 text-center">
          <p className="text-primary-foreground/60 flex items-center justify-center">
            Made with <Heart className="w-4 h-4 mx-1 text-red-400" /> by AtoZ Tools Team
          </p>
        </div>
      </div>
    </footer>
  );
};