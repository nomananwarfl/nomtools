import { ToolCard } from "./ToolCard";
import {
  FileText, RotateCcw, Type, Image, Edit3, Palette, 
  Shield, Key, CheckCircle, Calculator, Percent, 
  Calendar, Ruler, Thermometer, Weight, Clock,
  Code, Zap, Settings, Globe
} from "lucide-react";

export const ToolsSection = () => {
  const toolCategories = [
    {
      title: "Text Analysis Tools",
      icon: FileText,
      tools: [
        { title: "Rewrite Article", icon: Edit3 },
        { title: "Case Converter", icon: Type },
        { title: "Reverse Text Generator", icon: RotateCcw },
        { title: "JPG To Word", icon: Image },
        { title: "Image to Text Converter", icon: FileText },
        { title: "Online Text Editor", icon: Edit3 },
        { title: "RGB to Hex Converter", icon: Palette },
        { title: "Small Text Generator", icon: Type },
        { title: "Word Combiner", icon: FileText }
      ]
    },
    {
      title: "Password Management Tools",
      icon: Shield,
      tools: [
        { title: "MD5 Generator", icon: Code },
        { title: "WordPress Password Generator", icon: Key },
        { title: "Password Strength Checker", icon: CheckCircle },
        { title: "Password Generator", icon: Key }
      ]
    },
    {
      title: "Online Calculators",
      icon: Calculator,
      tools: [
        { title: "Age Calculator", icon: Calendar },
        { title: "Percentage Calculator", icon: Percent },
        { title: "Average Calculator", icon: Calculator },
        { title: "Sales Tax Calculator", icon: Calculator },
        { title: "Discount Calculator", icon: Percent },
        { title: "Probability Calculator", icon: Calculator }
      ]
    },
    {
      title: "Unit Converters",
      icon: Ruler,
      tools: [
        { title: "Length Converter", icon: Ruler },
        { title: "Weight Converter", icon: Weight },
        { title: "Temperature Converter", icon: Thermometer },
        { title: "Time Converter", icon: Clock },
        { title: "Speed Converter", icon: Zap },
        { title: "Volume Converter", icon: Calculator }
      ]
    }
  ];

  return (
    <section className="py-16">
      <div className="container mx-auto px-4">
        {toolCategories.map((category, categoryIndex) => (
          <div key={categoryIndex} className="mb-16">
            <div className="flex items-center mb-8">
              <div className="w-10 h-10 rounded-lg bg-gradient-primary flex items-center justify-center mr-4">
                <category.icon className="w-6 h-6 text-white" />
              </div>
              <h2 className="text-3xl font-bold text-foreground">
                {category.title}
              </h2>
            </div>
            
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {category.tools.map((tool, toolIndex) => (
                <ToolCard
                  key={toolIndex}
                  title={tool.title}
                  icon={tool.icon}
                />
              ))}
            </div>
          </div>
        ))}
      </div>
    </section>
  );
};