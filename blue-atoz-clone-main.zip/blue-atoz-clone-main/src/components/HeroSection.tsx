import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Search } from "lucide-react";

export const HeroSection = () => {
  return (
    <section className="bg-gradient-hero text-white py-20">
      <div className="container mx-auto px-4 text-center">
        <h1 className="text-5xl md:text-6xl font-bold mb-6 animate-float">
          Nom Tools
        </h1>
        <p className="text-xl md:text-2xl mb-8 text-white/90 max-w-2xl mx-auto">
          Your ultimate collection of online tools for productivity, analysis, and conversion
        </p>
        
        {/* Search Bar */}
        <div className="max-w-2xl mx-auto mb-8">
          <div className="relative">
            <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 text-muted-foreground w-5 h-5" />
            <Input 
              placeholder="Search for tools..." 
              className="pl-12 pr-4 py-6 text-lg rounded-full border-0 bg-white/10 backdrop-blur-sm text-white placeholder:text-white/70 focus:bg-white/20 transition-all"
            />
          </div>
        </div>

        <Button 
          size="lg" 
          className="bg-white text-primary hover:bg-white/90 transition-all shadow-blue-lg px-8 py-6 text-lg rounded-full"
        >
          Explore All Tools
        </Button>
      </div>
    </section>
  );
};